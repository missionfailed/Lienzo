# Lienzo
Compiladores EM 2016
Primera Entrega: Scanner y Parser en ANTLR

INSTRUCCIONES

Para windows:

Tener Python instalado

Instalar el jar de esta pagina:
http://www.antlr.org/download/antlr-4.5.2-complete.jar

ponerlo en el directorio C:\

Extraer los archivos en el escritorio
Irse al escritorio en la linea de comandos
Ejecutar lo siguiente:

java -jar C:\antlr-4.5.2-complete.jar -Dlanguage=Python3 Lienzo.g4

y luego

python script.py ProgramaPrueba1.txt


